#ifndef GENERARGOLES_H
#define GENERARGOLES_H


class GenerarGoles
{
    public:
        GenerarGoles();
        virtual ~GenerarGoles();
        static int generarGolesAleatorios(int maxGoles);

    protected:

    private:
};

#endif // GENERARGOLES_H
