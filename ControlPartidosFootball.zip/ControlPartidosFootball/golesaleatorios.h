#ifndef GOLESALEATORIOS_H
#define GOLESALEATORIOS_H


class GolesAleatorios
{
    public:
        GolesAleatorios();
        virtual ~GolesAleatorios();

    protected:

    private:
};

#endif // GOLESALEATORIOS_H
