#ifndef PARTIDOS_H
#define PARTIDOS_H


class Partidos
{
    public:
        Partidos();
        virtual ~Partidos();

    protected:

    private:
};

#endif // PARTIDOS_H
