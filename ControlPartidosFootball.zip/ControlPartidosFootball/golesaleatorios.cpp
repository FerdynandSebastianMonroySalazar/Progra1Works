#include "golesaleatorios.h"

GolesAleatorios::GolesAleatorios()
{
    //ctor
}

GolesAleatorios::~GolesAleatorios()
{
    //dtor
}
