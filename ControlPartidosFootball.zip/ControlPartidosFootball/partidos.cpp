#include "partidos.h"

Partidos::Partidos()
{
    //ctor
}

Partidos::~Partidos()
{
    //dtor
}
